import sys

print sys.version[:3]
