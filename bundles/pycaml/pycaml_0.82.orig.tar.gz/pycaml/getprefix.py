import sys

print sys.exec_prefix
