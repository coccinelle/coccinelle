let lowercase = String.lowercase
