let lowercase = String.lowercase_ascii
