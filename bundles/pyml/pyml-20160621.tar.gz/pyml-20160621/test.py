print("Hello from file!")
