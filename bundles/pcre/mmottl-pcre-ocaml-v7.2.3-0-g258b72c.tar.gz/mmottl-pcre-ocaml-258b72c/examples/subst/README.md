Start the program with argument "-help" to see what it does!

Example invocation:

    subst '([Tt])ermcap' '$1ermCap' < /etc/termcap
