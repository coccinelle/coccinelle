let string_copy str = str
let buffer_add_subbytes = Buffer.add_subbytes
