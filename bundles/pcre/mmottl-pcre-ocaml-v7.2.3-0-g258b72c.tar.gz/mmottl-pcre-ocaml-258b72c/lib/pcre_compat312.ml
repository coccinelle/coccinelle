let string_copy = String.copy
let buffer_add_subbytes = Buffer.add_substring
