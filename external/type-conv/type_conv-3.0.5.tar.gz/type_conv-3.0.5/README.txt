The type-conv mini library factors out functionality needed by different
preprocessors that generate code from type specifications, because this
functionality cannot be duplicated without losing the ability to use
these preprocessors simultaneously.
